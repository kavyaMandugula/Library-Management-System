$(document).ready(function() {
  $('#registrationForm').submit(function(event) {
      event.preventDefault();
      
      // Validate form
      var fullName = $('#fullName').val();
      var email = $('#email').val();
      var password = $('#password').val();
      var confirmPassword = $('#confirmPassword').val();

      if (password !== confirmPassword) {
          alert("Passwords do not match!");
          return;
      }

      // Prepare data for API call
      var userData = {
          fullName: fullName,
          email: email,
          password: password
      };

      // Make API call to register user
      $.ajax({
          url: '/api/users/register',
          type: 'POST',
          contentType: 'application/json',
          data: JSON.stringify(userData),
          success: function(response) {
              alert('Registration successful!');
              window.location.href = '/login.html'; // Redirect to login page
          },
          error: function(xhr, status, error) {
              alert('Registration failed: ' + xhr.responseText);
          }
      });
  });
});