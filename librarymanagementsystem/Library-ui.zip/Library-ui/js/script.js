$(document).ready(function() {
    $('#toggleAdvancedSearch').click(function() {
        $('#advancedSearch').toggle();
    });

    $('#searchForm').submit(function(event) {
        event.preventDefault();
        console.log("Basic search submitted");
        // Implement basic search functionality here
    });

    $('#advancedSearchForm').submit(function(event) {
        event.preventDefault();
        console.log("Advanced search submitted");
        // Implement the advanced search functionality here
        let isbn = $('#isbn').val();
        let author = $('#author').val();
        let title = $('#title').val();
        let publisher = $('#publisher').val();
        let status = $('#status').val();
        let publicationDate = $('#publicationDate').val();
        
        console.log("Search params:", {isbn, author, title, publisher, status, publicationDate});
    });
});